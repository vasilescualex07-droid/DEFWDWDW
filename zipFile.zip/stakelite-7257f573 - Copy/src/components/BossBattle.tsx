import { useMemo, useRef, useState, useEffect } from 'react';
import { Skull, Swords, Shield, Heart, Zap, Trophy, X, Flame, Star, Crown, Gift, Target, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { playSound } from '@/hooks/useSounds';
import { toast } from 'sonner';
import { UndertaleArena, type AttackPattern } from '@/components/boss/UndertaleArena';
import { DEFAULT_SLOT_CONFIG, computeDamage, modsFromLevel, rollSlotOutcome, type SlotOutcome } from '@/lib/slotCombat';
import { GameBurst } from '@/components/GameBurst';

interface BossBattleProps {
  balance: number;
  playerLevel: number;
  onWin: (amount: number, bet?: number, multiplier?: number) => void;
  onLose: (amount: number) => void;
  onBetPlaced?: (amount: number) => void;
  onClose: () => void;
}

interface Boss {
  id: string;
  name: string;
  title: string;
  health: number;
  damage: number;
  reward: number;
  color: string;
  minLevel: number;
  specialAbility: string;
  dropChance: number;
  rareDropReward: number;
}

interface PlayerAbility {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  damage: number;
  hitChance: number;
  cooldown: number;
  color: string;
  special?: 'heal' | 'dodge' | 'crit';
}

const BOSSES: Boss[] = [
  { id: 'dealer', name: 'The Dealer', title: 'Card Master', health: 100, damage: 12, reward: 500, color: 'from-green-500 to-emerald-700', minLevel: 5, specialAbility: 'Card Trick', dropChance: 0.15, rareDropReward: 1000 },
  { id: 'pit-boss', name: 'Pit Boss Pete', title: 'Floor Guardian', health: 180, damage: 20, reward: 1500, color: 'from-blue-500 to-blue-700', minLevel: 15, specialAbility: 'Floor Slam', dropChance: 0.12, rareDropReward: 3000 },
  { id: 'whale', name: 'The Whale', title: 'High Roller', health: 300, damage: 30, reward: 5000, color: 'from-purple-500 to-purple-700', minLevel: 25, specialAbility: 'Money Rain', dropChance: 0.10, rareDropReward: 10000 },
  { id: 'house', name: 'The House', title: 'Casino Boss', health: 450, damage: 45, reward: 15000, color: 'from-red-500 to-red-700', minLevel: 40, specialAbility: 'House Edge', dropChance: 0.08, rareDropReward: 30000 },
  { id: 'shadow', name: 'Shadow Dealer', title: 'Hidden Master', health: 600, damage: 55, reward: 35000, color: 'from-gray-700 to-black', minLevel: 55, specialAbility: 'Shadow Strike', dropChance: 0.06, rareDropReward: 75000 },
  { id: 'king', name: 'The Casino King', title: 'Ultimate Boss', health: 800, damage: 70, reward: 100000, color: 'from-gold to-amber-700', minLevel: 75, specialAbility: 'Royal Decree', dropChance: 0.05, rareDropReward: 250000 },
];

const ACTIONS = [
  { id: 'attack', name: 'Attack', icon: Swords, color: 'bg-orange-600 hover:bg-orange-700' },
  { id: 'focus', name: 'Focus', icon: Target, color: 'bg-red-600 hover:bg-red-700' },
  { id: 'heal', name: 'Heal', icon: Heart, color: 'bg-pink-600 hover:bg-pink-700' },
] as const;

type CombatAction = (typeof ACTIONS)[number]['id'];
type CombatPhase = 'playerTurn' | 'dodge' | 'ended';

const BOSS_SIGNATURE: Record<string, 'none' | 'dealerFan' | 'pitSweep' | 'whaleWave' | 'houseGrid' | 'shadowX' | 'kingCross'> = {
  dealer: 'dealerFan',
  'pit-boss': 'pitSweep',
  whale: 'whaleWave',
  house: 'houseGrid',
  shadow: 'shadowX',
  king: 'kingCross',
};

export const BossBattle = ({ balance, playerLevel, onWin, onLose, onBetPlaced, onClose }: BossBattleProps) => {
  const [selectedBoss, setSelectedBoss] = useState<Boss | null>(null);
  const [playerHealth, setPlayerHealth] = useState(100);
  const [maxPlayerHealth, setMaxPlayerHealth] = useState(100);
  const [bossHealth, setBossHealth] = useState(100);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [battleEnded, setBattleEnded] = useState(false);
  const [cooldowns, setCooldowns] = useState<Record<string, number>>({});
  const [phase, setPhase] = useState<CombatPhase>('playerTurn');
  const [focusActive, setFocusActive] = useState(false);
  const [bossVulnerableUntil, setBossVulnerableUntil] = useState<number>(0);
  const [timeScale, setTimeScale] = useState(1);
  const [attackPattern, setAttackPattern] = useState<AttackPattern>('rain');
  const [slotUI, setSlotUI] = useState<{ for: 'toBoss' | 'toPlayer'; outcome: SlotOutcome; base: number; damage: number } | null>(null);
  const [burst, setBurst] = useState<{ kind: 'boss' | 'player'; nonce: number } | null>(null);
  const [bossStats, setBossStats] = useState(() => {
    const saved = localStorage.getItem('boss_stats');
    return saved ? JSON.parse(saved) : { 
      totalKills: 0, 
      totalDeaths: 0, 
      bossesDefeated: {} as Record<string, number>,
      rareDrops: 0,
      totalEarned: 0,
    };
  });
  const [betAmount] = useState(50);
  const entryChargedRef = useRef(false);

  useEffect(() => {
    localStorage.setItem('boss_stats', JSON.stringify(bossStats));
  }, [bossStats]);

  const startBattle = (boss: Boss) => {
    if (balance < betAmount) {
      toast.error('Need at least $50 to challenge a boss!');
      return;
    }
    setSelectedBoss(boss);
    const playerMaxHp = 100 + playerLevel * 3;
    setPlayerHealth(playerMaxHp);
    setMaxPlayerHealth(playerMaxHp);
    setBossHealth(boss.health);
    setBattleLog([
      `⚔️ Battle started against ${boss.name}!`,
      `💬 ${boss.name}: "You dare challenge me?"`,
      `🎰 Slots decide damage when you hit OR get hit.`,
      `❤️ Dodge in the box during enemy turns.`,
    ]);
    setBattleEnded(false);
    setCooldowns({});
    setPhase('playerTurn');
    setFocusActive(false);
    setBossVulnerableUntil(0);
    setTimeScale(1);
    setAttackPattern('rain');
    setSlotUI(null);
    setBurst(null);
    entryChargedRef.current = true;
    (onBetPlaced ?? onLose)(betAmount);
    playSound('click');
  };

  const slotMods = useMemo(() => modsFromLevel(playerLevel), [playerLevel]);
  const bossDifficulty = useMemo(() => {
    if (!selectedBoss) return { cadenceMs: 1000, telegraphMs: 700, strikeMs: 180, maxSlashes: 2, moveSpeed: 185 };
    const t = Math.min(1, selectedBoss.minLevel / 75);
    return {
      cadenceMs: Math.round(1050 - t * 380), // stronger boss = more frequent
      telegraphMs: Math.round(780 - t * 260), // stronger boss = shorter warning
      strikeMs: Math.round(170 + t * 70),
      maxSlashes: 2 + (t > 0.7 ? 1 : 0),
      moveSpeed: 185,
    };
  }, [selectedBoss]);
  const bossSignature = selectedBoss ? BOSS_SIGNATURE[selectedBoss.id] ?? 'none' : 'none';

  const choosePattern = (bossHp: number, maxHp: number): AttackPattern => {
    const pct = maxHp > 0 ? bossHp / maxHp : 1;
    if (pct > 0.66) return 'rain';
    if (pct > 0.33) return 'cross';
    return 'walls';
  };

  const reduceCooldowns = () => {
    setCooldowns(prev => {
      const newCooldowns: Record<string, number> = {};
      for (const [key, value] of Object.entries(prev)) {
        if (value > 1) newCooldowns[key] = value - 1;
      }
      return newCooldowns;
    });
  };

  const applyJackpotEffect = (outcome: SlotOutcome) => {
    if (!selectedBoss || !outcome.effect) return;
    if (outcome.effect === 'slowMo') {
      setBattleLog(prev => [...prev, `⏳ JACKPOT: Slow-motion!`]);
      setTimeScale(0.55);
      setTimeout(() => setTimeScale(1), 1600);
      return;
    }
    if (outcome.effect === 'bossInterrupt') {
      setBattleLog(prev => [...prev, `🧨 JACKPOT: Phase interrupt!`]);
      setPhase('playerTurn');
      return;
    }
    if (outcome.effect === 'vulnerability') {
      const until = Date.now() + 2500;
      setBossVulnerableUntil(until);
      setBattleLog(prev => [...prev, `🩸 JACKPOT: Boss vulnerable!`]);
      return;
    }
    if (outcome.effect === 'damageBurst') {
      setBattleLog(prev => [...prev, `💥 JACKPOT: Damage burst!`]);
    }
  };

  const doSlotRoll = (forWho: 'toBoss' | 'toPlayer', baseDamage: number) => {
    const outcome = rollSlotOutcome(DEFAULT_SLOT_CONFIG, slotMods);
    applyJackpotEffect(outcome);

    const vuln = forWho === 'toBoss' && Date.now() < bossVulnerableUntil ? 1.6 : 1;
    const burstBonus = outcome.tier === 'jackpot' && outcome.effect === 'damageBurst' ? 1.35 : 1;
    const damage = computeDamage(baseDamage, outcome, { ...slotMods, damageScalar: (slotMods.damageScalar ?? 1) * vuln * burstBonus });
    setSlotUI({ for: forWho, outcome, base: baseDamage, damage });
    return { outcome, damage };
  };

  const onPlayerAction = (action: CombatAction) => {
    if (battleEnded || !selectedBoss) return;
    if (phase !== 'playerTurn') return;
    if (cooldowns[action] && cooldowns[action] > 0) return;

    if (action === 'heal') {
      setCooldowns(prev => ({ ...prev, heal: 3 }));
      const healAmount = 22 + Math.floor(playerLevel * 0.6);
      setPlayerHealth(h => Math.min(maxPlayerHealth, h + healAmount));
      setBattleLog(prev => [...prev, `💚 You heal for ${healAmount} HP.`]);
      playSound('cashout');
      reduceCooldowns();
      setPhase('dodge');
      setAttackPattern(choosePattern(bossHealth, selectedBoss.health));
      return;
    }

    if (action === 'focus') {
      setCooldowns(prev => ({ ...prev, focus: 3 }));
      setFocusActive(true);
      setBattleLog(prev => [...prev, `🎯 Focus: higher odds for one roll.`]);
      playSound('click');
      reduceCooldowns();
      setPhase('dodge');
      setAttackPattern(choosePattern(bossHealth, selectedBoss.health));
      return;
    }

    // Attack -> roll slots to damage boss.
    const base = 14 + Math.floor(playerLevel * 1.8);
    const boostedMods = focusActive ? { ...slotMods, highBias: (slotMods.highBias ?? 0) + 6, jackpotBias: (slotMods.jackpotBias ?? 0) + 0.6 } : slotMods;
    const outcome = rollSlotOutcome(DEFAULT_SLOT_CONFIG, boostedMods);
    setFocusActive(false);
    applyJackpotEffect(outcome);
    const vuln = Date.now() < bossVulnerableUntil ? 1.6 : 1;
    const burstBonus = outcome.tier === 'jackpot' && outcome.effect === 'damageBurst' ? 1.35 : 1;
    const damage = computeDamage(base, outcome, { ...boostedMods, damageScalar: (boostedMods.damageScalar ?? 1) * vuln * burstBonus });
    setSlotUI({ for: 'toBoss', outcome, base, damage });

    setBossHealth(h => Math.max(0, h - damage));
    setBattleLog(prev => [...prev, `🗡️ You strike! Slots rolled ${outcome.tier.toUpperCase()} → ${damage} dmg.`]);
    setBurst({ kind: 'boss', nonce: Date.now() });
    playSound(damage > 0 ? 'win' : 'click');

    const nextBossHp = Math.max(0, bossHealth - damage);
    if (nextBossHp === 0) {
      handleVictory();
      return;
    }

    reduceCooldowns();
    setPhase('dodge');
    setAttackPattern(choosePattern(nextBossHp, selectedBoss.health));
  };

  const onArenaHit = () => {
    if (!selectedBoss || battleEnded) return;
    const base = selectedBoss.damage + Math.floor(Math.random() * 8);
    const { outcome, damage } = doSlotRoll('toPlayer', base);
    setBattleLog(prev => [...prev, `💔 You got hit! Slots rolled ${outcome.tier.toUpperCase()} → ${damage} dmg.`]);
    setPlayerHealth(h => Math.max(0, h - damage));
    setBurst({ kind: 'player', nonce: Date.now() });
  };

  const onDodgeDone = () => {
    if (battleEnded) return;
    if (playerHealth <= 0) {
      handleDefeat();
      return;
    }
    reduceCooldowns();
    setPhase('playerTurn');
  };

  const handleVictory = () => {
    if (!selectedBoss) return;
    
    setBattleEnded(true);
    let totalReward = selectedBoss.reward;
    let logMessages = [`🏆 VICTORY! You defeated ${selectedBoss.name}!`];

    // Check for rare drop
    if (Math.random() < selectedBoss.dropChance) {
      totalReward += selectedBoss.rareDropReward;
      logMessages.push(`✨ RARE DROP! +$${selectedBoss.rareDropReward.toLocaleString()}!`);
      setBossStats((prev: typeof bossStats) => ({ ...prev, rareDrops: prev.rareDrops + 1 }));
    }

    setBattleLog(prev => [...prev, ...logMessages]);
    onWin(totalReward, betAmount, totalReward / betAmount);
    
    setBossStats((prev: typeof bossStats) => ({
      ...prev,
      totalKills: prev.totalKills + 1,
      totalEarned: prev.totalEarned + totalReward,
      bossesDefeated: {
        ...prev.bossesDefeated,
        [selectedBoss.id]: (prev.bossesDefeated[selectedBoss.id] || 0) + 1,
      },
    }));

    toast.success(`🏆 Boss defeated! +$${totalReward.toLocaleString()}`);
    playSound('cashout');
  };

  const handleDefeat = () => {
    if (!selectedBoss) return;
    
    setBattleEnded(true);
    setBattleLog(prev => [...prev, `💀 DEFEATED! ${selectedBoss.name} wins...`]);
    // Entry fee is deducted at battle start via onBetPlaced/onLose.
    
    setBossStats((prev: typeof bossStats) => ({
      ...prev,
      totalDeaths: prev.totalDeaths + 1,
    }));

    toast.error(`You were defeated!`);
    setPhase('ended');
  };

  if (!selectedBoss) {
    return (
      <Card className="bg-gradient-to-br from-card via-red-950/20 to-card border-lose/30">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-gradient-to-br from-lose/30 to-red-600/20 rounded-xl glow-red">
                <Skull className="w-6 h-6 text-lose" />
              </div>
              <div>
                <CardTitle className="font-display text-xl text-lose">BOSS BATTLES</CardTitle>
                <p className="text-xs text-lose/60">Challenge for massive rewards!</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Boss Stats */}
          <div className="grid grid-cols-4 gap-2">
            <div className="p-2 bg-win/10 rounded-lg border border-win/20 text-center">
              <p className="text-sm font-display text-win">{bossStats.totalKills}</p>
              <p className="text-[9px] text-muted-foreground">Kills</p>
            </div>
            <div className="p-2 bg-lose/10 rounded-lg border border-lose/20 text-center">
              <p className="text-sm font-display text-lose">{bossStats.totalDeaths}</p>
              <p className="text-[9px] text-muted-foreground">Deaths</p>
            </div>
            <div className="p-2 bg-gold/10 rounded-lg border border-gold/20 text-center">
              <p className="text-sm font-display text-gold">{bossStats.rareDrops}</p>
              <p className="text-[9px] text-muted-foreground">Rare Drops</p>
            </div>
            <div className="p-2 bg-neon-cyan/10 rounded-lg border border-neon-cyan/20 text-center">
              <p className="text-sm font-display text-neon-cyan">${(bossStats.totalEarned / 1000).toFixed(0)}k</p>
              <p className="text-[9px] text-muted-foreground">Earned</p>
            </div>
          </div>

          <p className="text-sm text-muted-foreground">Entry fee: $50 per battle</p>
          
          <div className="grid grid-cols-2 gap-3">
            {BOSSES.map((boss) => {
              const isLocked = playerLevel < boss.minLevel;
              const timesDefeated = bossStats.bossesDefeated[boss.id] || 0;
              return (
                <button
                  key={boss.id}
                  onClick={() => !isLocked && startBattle(boss)}
                  disabled={isLocked}
                  className={`relative p-4 rounded-xl bg-gradient-to-br ${boss.color} bg-opacity-20 border border-white/10 transition-all duration-300 ${isLocked ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 hover:shadow-lg'} group`}
                >
                  <div className="absolute inset-0 bg-black/60 rounded-xl" />
                  <div className="relative z-10 text-left">
                    <div className="flex items-center justify-between mb-2">
                      <Skull className={`w-8 h-8 ${isLocked ? 'text-gray-500' : 'text-white'}`} />
                      <div className="text-right">
                        {isLocked && <span className="text-xs text-gray-400 block">Lv.{boss.minLevel}</span>}
                        {timesDefeated > 0 && <span className="text-xs text-win">×{timesDefeated}</span>}
                      </div>
                    </div>
                    <h3 className="font-display text-sm text-white">{boss.name}</h3>
                    <p className="text-xs text-white/60">{boss.title}</p>
                    <div className="mt-2 flex items-center gap-2 text-xs flex-wrap">
                      <div className="flex items-center gap-1">
                        <Heart className="w-3 h-3 text-red-400" />
                        <span className="text-red-400">{boss.health}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Swords className="w-3 h-3 text-orange-400" />
                        <span className="text-orange-400">{boss.damage}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Trophy className="w-3 h-3 text-gold" />
                        <span className="text-gold">${(boss.reward / 1000).toFixed(0)}k</span>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center gap-1 text-[10px] text-purple-300">
                      <Sparkles className="w-3 h-3" />
                      <span>{boss.specialAbility}</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-card via-red-950/20 to-card border-lose/30 overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="font-display text-lg text-lose">VS {selectedBoss.name}</CardTitle>
          <Button variant="ghost" size="sm" onClick={() => setSelectedBoss(null)} disabled={phase === 'dodge' && !battleEnded}>
            {battleEnded ? 'Back' : 'Flee'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Health Bars */}
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-neon-cyan flex items-center gap-1">
                You
                {focusActive && <Target className="w-3 h-3 text-red-400" />}
              </span>
              <span className="text-neon-cyan">{playerHealth} / {maxPlayerHealth} HP</span>
            </div>
            <Progress value={(playerHealth / maxPlayerHealth) * 100} className="h-3 bg-secondary [&>div]:bg-gradient-to-r [&>div]:from-neon-cyan [&>div]:to-neon-blue" />
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-lose flex items-center gap-1">
                {selectedBoss.name}
                <span className="text-[10px] text-muted-foreground">({selectedBoss.specialAbility})</span>
                {Date.now() < bossVulnerableUntil && <Flame className="w-3 h-3 text-gold animate-text-glow-pulse" />}
              </span>
              <span className="text-lose">{bossHealth} / {selectedBoss.health} HP</span>
            </div>
            <Progress value={(bossHealth / selectedBoss.health) * 100} className="h-3 bg-secondary [&>div]:bg-gradient-to-r [&>div]:from-lose [&>div]:to-orange-500" />
          </div>
        </div>

        {/* Arena + actions */}
        {!battleEnded && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            <div className="relative">
              {burst?.kind === 'boss' && (
                <GameBurst id="slots" show key={`b-${burst.nonce}`} xPct={50} yPct={35} />
              )}
              {burst?.kind === 'player' && (
                <GameBurst id="roulette" show key={`p-${burst.nonce}`} xPct={50} yPct={55} />
              )}
              <UndertaleArena
                disabled={battleEnded}
                attackEnabled={phase === 'dodge'}
                pattern={attackPattern}
                signature={bossSignature}
                difficulty={bossDifficulty}
                durationMs={2600}
                timeScale={timeScale}
                onHit={() => onArenaHit()}
                onDone={onDodgeDone}
              />
            </div>

            <div className="space-y-3">
              <div className="bg-black/30 rounded-lg p-3 border border-gold/10">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-display tracking-wider text-gold/90">SLOT ROLL</div>
                  {phase === 'dodge' && <div className="text-[10px] text-muted-foreground">Enemy turn</div>}
                  {phase === 'playerTurn' && <div className="text-[10px] text-muted-foreground">Your turn</div>}
                </div>
                {slotUI ? (
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">
                      {slotUI.for === 'toBoss' ? 'To Boss' : 'To You'} · Base {slotUI.base}
                    </div>
                    <div className="font-display font-black text-gold">
                      {slotUI.outcome.symbol} · {slotUI.outcome.tier.toUpperCase()} · {slotUI.damage}
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-muted-foreground">Hit or get hit to roll.</div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-2">
                {ACTIONS.map((a) => {
                  const Icon = a.icon;
                  const cd = cooldowns[a.id] ?? 0;
                  const disabled = phase !== 'playerTurn' || cd > 0;
                  return (
                    <Button
                      key={a.id}
                      onClick={() => onPlayerAction(a.id)}
                      disabled={disabled}
                      className={`${a.color} flex flex-col h-auto py-2 relative ${disabled ? 'opacity-60' : ''}`}
                    >
                      <Icon className="w-4 h-4 mb-0.5" />
                      <span className="text-[10px]">{a.name}</span>
                      {cd > 0 && <span className="absolute top-1 right-1 text-[10px] bg-black/50 px-1 rounded">{cd}</span>}
                    </Button>
                  );
                })}
              </div>

              {Date.now() < bossVulnerableUntil && (
                <div className="text-xs text-gold/90 bg-gold/10 border border-gold/20 rounded-lg p-2">
                  Boss is vulnerable: damage boosted!
                </div>
              )}
              {timeScale < 1 && (
                <div className="text-xs text-neon-cyan bg-neon-cyan/10 border border-neon-cyan/20 rounded-lg p-2">
                  Slow-motion active
                </div>
              )}
            </div>
          </div>
        )}

        {/* Battle Log */}
        <div className="bg-black/30 rounded-lg p-3 h-36 overflow-y-auto">
          {battleLog.map((log, i) => (
            <p key={i} className="text-xs text-muted-foreground animate-slide-up">{log}</p>
          ))}
        </div>

        {/* Potential Rewards */}
        {!battleEnded && (
          <div className="flex items-center justify-center gap-4 text-xs">
            <div className="flex items-center gap-1 text-gold">
              <Trophy className="w-4 h-4" />
              <span>${selectedBoss.reward.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-1 text-purple-400">
              <Gift className="w-4 h-4" />
              <span>{(selectedBoss.dropChance * 100).toFixed(0)}% rare drop</span>
            </div>
          </div>
        )}

        {battleEnded && (
          <Button onClick={() => setSelectedBoss(null)} className="w-full bg-gradient-to-r from-neon-blue to-neon-purple">
            Continue
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
