import { Trophy, TrendingUp, Gamepad2 } from 'lucide-react';
import { Player } from '@/hooks/usePlayers';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

interface LeaderboardProps {
  players: Player[];
  biggestWinners: Player[];
  mostActive: Player[];
  currentPlayerName?: string;
}

const LeaderboardRow = ({ 
  player, 
  index, 
  isCurrentPlayer, 
  valueFormatter 
}: { 
  player: Player; 
  index: number; 
  isCurrentPlayer: boolean;
  valueFormatter: (p: Player) => string;
}) => (
  <div 
    className={`flex items-center justify-between py-1.5 px-2 rounded-lg text-sm transition-all ${
      isCurrentPlayer 
        ? 'bg-primary/20 border border-primary/30 shadow-[0_0_10px_hsl(var(--primary)/0.2)]' 
        : 'bg-background/30 hover:bg-background/50'
    }`}
  >
    <div className="flex items-center gap-2">
      <span className={`font-display text-xs w-5 ${
        index === 0 ? 'text-gold' : 
        index === 1 ? 'text-gray-400' : 
        index === 2 ? 'text-amber-700' : 'text-muted-foreground'
      }`}>
        {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}`}
      </span>
      <div className="flex items-center gap-1.5">
        <div className="w-5 h-5 rounded-full bg-gradient-to-br from-neon-blue/50 to-neon-cyan/50 flex items-center justify-center text-[10px] font-display font-bold">
          {player.level}
        </div>
        <span className="font-medium truncate max-w-[60px]">{player.name}</span>
      </div>
    </div>
    <span className={`font-display text-xs font-bold ${
      player.balance > 100 ? 'text-win' : player.balance < 100 ? 'text-lose' : 'text-foreground'
    }`}>
      {valueFormatter(player)}
    </span>
  </div>
);

export const Leaderboard = ({ players, biggestWinners, mostActive, currentPlayerName }: LeaderboardProps) => {
  return (
    <div className="bg-card/60 backdrop-blur-sm border border-border/40 rounded-xl p-4">
      <Tabs defaultValue="balance" className="space-y-3">
        <TabsList className="w-full h-8 bg-background/50 p-0.5">
          <TabsTrigger value="balance" className="flex-1 h-7 text-xs gap-1 data-[state=active]:bg-neon-blue/20 data-[state=active]:text-neon-blue">
            <Trophy className="w-3 h-3" />
            <span className="hidden sm:inline">Balance</span>
          </TabsTrigger>
          <TabsTrigger value="wins" className="flex-1 h-7 text-xs gap-1 data-[state=active]:bg-gold/20 data-[state=active]:text-gold">
            <TrendingUp className="w-3 h-3" />
            <span className="hidden sm:inline">Big Wins</span>
          </TabsTrigger>
          <TabsTrigger value="active" className="flex-1 h-7 text-xs gap-1 data-[state=active]:bg-neon-purple/20 data-[state=active]:text-neon-purple">
            <Gamepad2 className="w-3 h-3" />
            <span className="hidden sm:inline">Active</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="balance" className="mt-0">
          <div className="space-y-1.5 max-h-[180px] overflow-y-auto">
            {players.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-2">No players yet</p>
            ) : (
              players.map((player, index) => (
                <LeaderboardRow
                  key={player.name}
                  player={player}
                  index={index}
                  isCurrentPlayer={player.name.toLowerCase() === currentPlayerName?.toLowerCase()}
                  valueFormatter={(p) => `$${p.balance.toFixed(0)}`}
                />
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="wins" className="mt-0">
          <div className="space-y-1.5 max-h-[180px] overflow-y-auto">
            {biggestWinners.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-2">No wins yet</p>
            ) : (
              biggestWinners.filter(p => p.stats.biggestWin > 0).map((player, index) => (
                <LeaderboardRow
                  key={player.name}
                  player={player}
                  index={index}
                  isCurrentPlayer={player.name.toLowerCase() === currentPlayerName?.toLowerCase()}
                  valueFormatter={(p) => `$${p.stats.biggestWin.toFixed(0)}`}
                />
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="active" className="mt-0">
          <div className="space-y-1.5 max-h-[180px] overflow-y-auto">
            {mostActive.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-2">No activity yet</p>
            ) : (
              mostActive.filter(p => p.stats.gamesPlayed > 0).map((player, index) => (
                <LeaderboardRow
                  key={player.name}
                  player={player}
                  index={index}
                  isCurrentPlayer={player.name.toLowerCase() === currentPlayerName?.toLowerCase()}
                  valueFormatter={(p) => `${p.stats.gamesPlayed} games`}
                />
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
