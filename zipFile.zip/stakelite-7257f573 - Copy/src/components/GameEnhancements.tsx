import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Sparkles, Zap, Flame, Award, TrendingUp, Clock, Target } from 'lucide-react';

interface GameEnhancementsProps {
  onBoostClick?: () => void;
  onSpecialMode?: () => void;
}

export const GameEnhancements = ({ onBoostClick, onSpecialMode }: GameEnhancementsProps) => {
  const [combo, setCombo] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (combo > 0) {
        setCombo(prev => Math.max(0, prev - 1));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [combo]);

  const triggerBoost = () => {
    setCombo(prev => prev + 1);
    setMultiplier(prev => Math.min(5, prev + 0.5));
    setStreak(prev => prev + 1);
    onBoostClick?.();
  };

  return (
    <>
      {/* Combo Counter */}
      <div className="fixed top-20 left-4 z-40">
        <Card className="bg-gradient-to-r from-purple-900/80 to-blue-900/80 border-purple-500/30 p-3 backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-400" />
            <div>
              <div className="text-xs text-purple-200">Combo</div>
              <div className="text-xl font-bold text-white">{combo}x</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Multiplier Display */}
      <div className="fixed top-20 right-4 z-40">
        <Card className="bg-gradient-to-r from-green-900/80 to-emerald-900/80 border-green-500/30 p-3 backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            <div>
              <div className="text-xs text-green-200">Multiplier</div>
              <div className="text-xl font-bold text-white">{multiplier.toFixed(1)}x</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Win Streak */}
      <div className="fixed top-40 left-4 z-40">
        <Card className="bg-gradient-to-r from-yellow-900/80 to-orange-900/80 border-yellow-500/30 p-3 backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-400" />
            <div>
              <div className="text-xs text-yellow-200">Streak</div>
              <div className="text-xl font-bold text-white">{streak}</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Boost Button */}
      <div className="fixed bottom-4 left-4 z-40">
        <Button
          onClick={triggerBoost}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold px-6 py-3 rounded-full shadow-lg shadow-purple-500/30 transition-all hover:scale-105"
        >
          <Sparkles className="w-5 h-5 mr-2" />
          BOOST
        </Button>
      </div>

      {/* Special Mode Button */}
      <div className="fixed bottom-4 right-4 z-40">
        <Button
          onClick={onSpecialMode}
          className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white font-bold px-6 py-3 rounded-full shadow-lg shadow-red-500/30 transition-all hover:scale-105"
        >
          <Zap className="w-5 h-5 mr-2" />
          SPECIAL
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40">
        <Card className="bg-black/80 border-white/10 p-2 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Target className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-gray-300">Accuracy</span>
              <span className="text-sm font-bold text-white">85%</span>
            </div>
            <div className="w-px h-4 bg-gray-600" />
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-green-400" />
              <span className="text-xs text-gray-300">Speed</span>
              <span className="text-sm font-bold text-white">Fast</span>
            </div>
            <div className="w-px h-4 bg-gray-600" />
            <div className="flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-gray-300">Luck</span>
              <span className="text-sm font-bold text-white">High</span>
            </div>
          </div>
        </Card>
      </div>
    </>
  );
};
