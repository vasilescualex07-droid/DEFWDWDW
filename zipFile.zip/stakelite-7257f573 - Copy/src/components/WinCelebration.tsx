import { useEffect, useState } from 'react';
import { playSound } from '@/hooks/useSounds';
import { formatNumber } from '@/lib/utils';
import { RoguelikeSparkles } from '@/components/RoguelikeSparkles';

interface WinCelebrationProps {
  show: boolean;
  profit?: number;
  onComplete?: () => void;
}

export const WinCelebration = ({ show, profit = 0, onComplete }: WinCelebrationProps) => {
  const [visible, setVisible] = useState(false);
  const [scale, setScale] = useState(0);
  const [glowIntensity, setGlowIntensity] = useState(0);

  useEffect(() => {
    if (show) {
      setVisible(true);
      setScale(0);
      setGlowIntensity(0);
      
      playSound('levelup');
      
      // Roguelike-style dramatic scale: overshoot then settle
      setTimeout(() => { setScale(1.5); setGlowIntensity(1); }, 20);
      setTimeout(() => setScale(0.88), 120);
      setTimeout(() => setScale(1.08), 220);
      setTimeout(() => setScale(1), 380);
      
      let frame = 0;
      const interval = setInterval(() => {
        frame++;
        setGlowIntensity(0.5 + Math.sin(frame * 0.18) * 0.5);
        if (frame > 70) {
          clearInterval(interval);
          setScale(0);
          setGlowIntensity(0);
          setTimeout(() => {
            setVisible(false);
            onComplete?.();
          }, 260);
        }
      }, 32);
      return () => clearInterval(interval);
    }
  }, [show, onComplete]);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      <div 
        className="absolute inset-0"
        style={{
          opacity: 0.3 + glowIntensity * 0.45,
          background:
            'radial-gradient(circle at 50% 45%, rgba(234,242,255,0.28) 0%, rgba(159,231,255,0.2) 32%, rgba(111,0,255,0.1) 62%, transparent 100%)',
        }}
      />
      <div className="absolute inset-0 summon-rays" style={{ opacity: 0.28 + glowIntensity * 0.35 }} />
      <div className="absolute inset-0 summon-ring" style={{ opacity: 0.2 + glowIntensity * 0.4 }} />
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
        <div className="relative flex justify-center">
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 pointer-events-none">
            <RoguelikeSparkles variant="mixed" count={12} size="md" spread={70} mode="float" />
          </div>
          <div 
            className="relative z-10 text-5xl md:text-8xl font-display font-black tracking-[0.2em] uppercase animate-pop-burst"
            style={{ 
              transform: `scale(${scale})`,
              background: 'linear-gradient(180deg, #fff3a0 0%, #ffd700 25%, #ffb700 50%, #b8860b 75%, #ffd700 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              filter: `drop-shadow(0 0 ${34 * glowIntensity}px rgba(255,215,0,0.95)) drop-shadow(0 0 ${70 * glowIntensity}px rgba(255,180,0,0.5)) drop-shadow(0 3px 6px rgba(0,0,0,0.9))`,
              transition: 'transform 0.12s cubic-bezier(0.34, 1.56, 0.64, 1)',
            }}
          >
            ⚔ VICTORY ⚔
          </div>
        </div>
        {profit > 0 && (
          <div 
            className="font-display font-black text-3xl md:text-5xl text-gold animate-pop-burst relative z-10"
            style={{
              textShadow: '0 0 24px rgba(255,215,0,0.9), 0 0 48px rgba(255,180,0,0.5), 0 2px 4px rgba(0,0,0,0.8)',
              animationDelay: '0.15s',
              animationFillMode: 'backwards',
            }}
          >
            +${formatNumber(profit)}
          </div>
        )}
      </div>
      
      <div 
        className="absolute inset-0 transition-opacity duration-150"
        style={{ 
          opacity: glowIntensity * 0.45,
          background: 'radial-gradient(circle at 50% 50%, rgba(255,215,0,0.18) 0%, rgba(255,255,255,0.12) 28%, transparent 56%)',
        }}
      />
      <div 
        className="absolute inset-0 transition-opacity duration-150"
        style={{ 
          opacity: glowIntensity * 0.25,
          background: 'radial-gradient(circle at 50% 50%, rgba(111,0,255,0.14), transparent 65%)',
        }}
      />
    </div>
  );
};